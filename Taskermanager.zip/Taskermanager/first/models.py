from django.db import models

# Create your models here.
class user(models.Model):
    username = models.TextField()
    emailid = models.EmailField()
    ph_no = models.IntegerField()
    password = models.TextField()

    def __set__(self):
    	return self.username

class personal_todo(models.Model):
	task = models.TextField()
	task_status = models.BooleanField()
	date = models.TextField()
	created_date = models.DateField()
	username = models.TextField()

class team_details(models.Model):
	team_name = models.TextField()
	team_description = models.TextField()
	created_date = models.DateField()
	created_by = models.TextField()

class team_members(models.Model):
	team_name = models.TextField()
	member_name = models.TextField()

class teamtasks(models.Model):
	team_name = models.TextField()
	date = models.DateField(default="")
	team_task_name = models.TextField()
	team_task_description = models.TextField()
	task_status = models.TextField()
	task_created_by = models.TextField()
	
class teamtaskmembers(models.Model):
	task_id = models.IntegerField()
	assignee = models.TextField()
	task_status = models.TextField()
	team_name = models.TextField()

class commentreply(models.Model):
	team_name = models.TextField()
	task_status = models.TextField()
	comment = models.TextField()
	task_id = models.IntegerField()
	commented_by = models.TextField()